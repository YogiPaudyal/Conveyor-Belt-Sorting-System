// CONFIG1
#pragma config FEXTOSC = ECH    // External Oscillator mode selection bits (EC above 8MHz; PFM set to high power)
#pragma config RSTOSC = EXT1X   // Power-up default value for COSC bits (EXTOSC operating per FEXTOSC bits)
#pragma config CLKOUTEN = OFF   // Clock Out Enable bit (CLKOUT function is disabled; i/o or oscillator function on OSC2)
#pragma config CSWEN = ON       // Clock Switch Enable bit (Writing to NOSC and NDIV is allowed)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable bit (FSCM timer enabled)
// CONFIG2
#pragma config MCLRE = ON       // Master Clear Enable bit (MCLR pin is Master Clear function)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config LPBOREN = OFF    // Low-Power BOR enable bit (ULPBOR disabled)
#pragma config BOREN = ON       // Brown-out reset enable bits (Brown-out Reset Enabled, SBOREN bit is ignored)
#pragma config BORV = LO        // Brown-out Reset Voltage Selection (Brown-out Reset Voltage (VBOR) set to 1.9V on LF, and 2.45V on F Devices)
#pragma config ZCD = OFF        // Zero-cross detect disable (Zero-cross detect circuit is disabled at POR.)
#pragma config PPS1WAY = ON     // Peripheral Pin Select one-way control (The PPSLOCK bit can be cleared and set only once in software)
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable bit (Stack Overflow or Underflow will cause a reset)
// CONFIG3
#pragma config WDTCPS = WDTCPS_31// WDT Period Select bits (Divider ratio 1:65536; software control of WDTPS)
#pragma config WDTE = ON        // WDT operating mode (WDT enabled regardless of sleep; SWDTEN ignored)
#pragma config WDTCWS = WDTCWS_7// WDT Window Select bits (window always open (100%); software control; keyed access not required)
#pragma config WDTCCS = SC      // WDT input clock selector (Software Control)
// CONFIG4
#pragma config WRT = OFF        // UserNVM self-write protection bits (Write protection off)
#pragma config SCANE = available// Scanner Enable bit (Scanner module is available for use)
#pragma config LVP = ON         // Low Voltage Programming Enable bit (Low Voltage programming enabled. MCLR/Vpp pin function is MCLR.)
// CONFIG5
#pragma config CP = OFF         // UserNVM Program memory code protection bit (Program Memory code protection disabled)
#pragma config CPD = OFF        // DataNVM code protection bit (Data EEPROM code protection disabled)

#include <xc.h>

// Threshold values for weight classification, adjust based on calibration
#define WEIGHT_THRESHOLD  500  // Example threshold for light objects

// LED output pins for weight indication
#define LED_LIGHT   RD3  // LED for "light" indication

// Define the system frequency for delay
#define _XTAL_FREQ 8000000     

    void ADC_Initialize(void) {
    // Set the ADC conversion clock
    // FRC is the default clock source, ADCS bits might need configuration based on desired conversion time
    ADCON0bits.ADCS = 0; //Yogi - changed from 0b111
    
    // Set the result format to right justified
    ADCON0bits.ADFRM0 = 1; //Yogi - might need to be set to 0 and changed to ADFRM
    
    // Select the ADC input channel, AN0 in this case
    ADPCH = 0x00; // AN0 //Yogi - might need to be changed to pin for ANO on MCU (datasheet)?)
    
    // Turn on the ADC module
    ADCON0bits.ADON = 1;
}

unsigned int ADC_Read(void) {
    // Start the ADC conversion
    ADCON0bits.ADGO = 1; // Start conversion

    // Wait for the conversion to finish
    while (ADCON0bits.ADGO);

    // Combine the high and low bytes of the result
    //while (ADCON0bits.ADGO){// Combine the high and low bytes of the result
    return ((unsigned int)ADRESH << 8) | ADRESL;
        //}
}

void main(void) {
    // Initialize ADC
    ADC_Initialize();
    
    // LED_LIGHT as output
    TRISDbits.TRISD3 = 0; 
    TRISAbits.TRISA1 = 0;
    
    while (1) {
        unsigned int adcResult = ADC_Read();

        if(adcResult < WEIGHT_THRESHOLD) {
            // Light object
            RD3 = 0;
            LATAbits.LATA1 = 0;
            __delay_ms(500);}
        
            else {
            // If not, turn off LED_LIGHT
            RD3 = 1;
            LATAbits.LATA1 = 1;
            __delay_ms(500);
        }
    }   
}


