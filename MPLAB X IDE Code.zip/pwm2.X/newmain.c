#include <xc.h>

// CONFIG1
#pragma config FOSC = INTOSC    // Internal Oscillator, I/O function on CLKIN pin
#pragma config WDTE = OFF       // Watchdog Timer Disable
#pragma config PWRTE = OFF      // Power-up Timer Disable
#pragma config MCLRE = ON       // MCLR/VPP Pin Function is MCLR
#pragma config CP = OFF         // Program Memory Code Protection off
#pragma config CPD = OFF        // Data Memory Code Protection off
#pragma config BOREN = ON       // Brown-out Reset Enable
#pragma config CLKOUTEN = OFF   // Clock Out Disable
#pragma config IESO = OFF       // Internal/External Switchover Mode off
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable

// CONFIG2
#pragma config WRT = OFF        // Flash Memory Self-Write Protection off
#pragma config PLLEN = OFF      // PLL Enable bit off
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable
#pragma config BORV = LO        // Brown-out Reset Voltage (Low)
#pragma config LVP = ON         // Low-Voltage Programming Enable

#define _XTAL_FREQ 32000000     // Oscillator Frequency as 32MHz

// Define LCD control pins
#define RS LATBbits.LATB5       
#define EN LATBbits.LATB4       
#define D0 LATBbits.LATB3       
#define D1 LATBbits.LATB2       
#define D2 LATBbits.LATB1       
#define D3 LATBbits.LATB0       
#define D4 LATDbits.LATD7       
#define D5 LATDbits.LATD6       
#define D6 LATDbits.LATD5       
#define D7 LATDbits.LATD4       

void LCD_Enable(void) {
    EN = 1;
    __delay_us(500); // Delay for enabling
    EN = 0;
    __delay_us(500); // Delay to complete the enable cycle
}

void LCD_Command(unsigned char cmd) {
    RS = 0; // Command mode
    D0 = (cmd & 0x01);
    D1 = (cmd & 0x02) >> 1;
    D2 = (cmd & 0x04) >> 2;
    D3 = (cmd & 0x08) >> 3;
    D4 = (cmd & 0x10) >> 4;
    D5 = (cmd & 0x20) >> 5;
    D6 = (cmd & 0x40) >> 6;
    D7 = (cmd & 0x80) >> 7;
    LCD_Enable();
}

void LCD_Init() {
    ANSELB = 0x00;  // Set PORTB pins as digital
    ANSELD = 0x00;  // Set PORTD pins as digital
    TRISB = 0x00; // Set PORTB as output
    TRISD = 0x00; // Set PORTD as output
    // Initialization sequence
    __delay_ms(20); // Power-up delay
    LCD_Command(0x30); // Function set: 8-bit, 2 lines, 5x8 dots
    LCD_Command(0x0C); // Display ON, Cursor OFF, Blink OFF
    LCD_Command(0x01); // Clear display
    LCD_Command(0x06); // Entry mode set: Increment cursor, No shift
    __delay_ms(2);
}

void LCD_Char(unsigned char data) {
    RS = 1; // Data mode
    D0 = (data & 0x01);
    D1 = (data & 0x02) >> 1;
    D2 = (data & 0x04) >> 2;
    D3 = (data & 0x08) >> 3;
    D4 = (data & 0x10) >> 4;
    D5 = (data & 0x20) >> 5;
    D6 = (data & 0x40) >> 6;
    D7 = (data & 0x80) >> 7;
    LCD_Enable();
}

void LCD_String(const char* str) {
    while(*str) LCD_Char(*str++);
}

void main(void) {
    // Initialize the LCD
    LCD_Init();
    LCD_Command(0x80); // Move cursor to the 6th position of the first line
    LCD_String("Total:");
    LCD_Command(0x80 + 8); // Move cursor to the 6th position of the first line
    LCD_String("A:");
    LCD_Command(0x80 + 12); // Move cursor to the 6th position of the first line
    LCD_String("B:");
    while(1);
}   